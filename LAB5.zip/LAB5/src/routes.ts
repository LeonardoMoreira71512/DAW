import express, { Router, Request, Response } from 'express';
import { functTransformOne, getAllUsers, getSomeUsers } from "./externalAPI";
import cache from './cachingRoutes';

const router : Router = express.Router();

router.get('/', cache(10), async(req:Request,res:Response)=>{
    const data = await getAllUsers();
    const arr = Object.entries(data).map(functTransformOne);
    console.log(arr);
    res.json(arr);
});

router.get("/city/:nameCity", cache(10), async(req:Request,res:Response)=>{
    const data = await getSomeUsers(req.params.nameCity);
    const arr = Object.entries(data).map(functTransformOne);
    console.log(arr);
    res.json(arr);
});

export default router;