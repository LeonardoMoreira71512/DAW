import fetch from 'node-fetch';

const MY_API = "https://jsonplaceholder.typicode.com/users";
export async function getAllUsers() {
    try {
        const response = await fetch(MY_API);
        const data = await response.json();
        return data;
    } catch(error) {
        console.error(error);
    }
}

export async function getSomeUsers(city: string) {
    try { 
        const response = await fetch(MY_API + "?address.city" + "=" + city);
        const data = await response.json();
        return data;
    } catch(error) {
        console.error(error);
    }
}

interface myType {
    [key:string]: string;
}

export function functTransformOne(element :[string,unknown]){
    const myElement: myType = element[1] as myType;
    return({identification: myElement.id,
        fullName: myElement.username,
        email: myElement.email,
        address: myElement.address,
        phone: myElement.phone,
        website: myElement.website,
    })
}